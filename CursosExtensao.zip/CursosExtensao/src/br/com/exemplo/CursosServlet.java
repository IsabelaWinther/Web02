package br.com.exemplo;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/CursosServlet")
public class CursosServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        String nome = request.getParameter("nome");

        String[] emails = request.getParameterValues("email");
        String[] cursos = request.getParameterValues("curso");

        out.println("<!DOCTYPE html>");
        out.println("<html lang='pt-BR'>");
        out.println("<head><meta charset='UTF-8'><title>Resultado</title></head>");
        out.println("<body>");
        out.println("<h2>Dados informados</h2>");

        out.println("<p><strong>Nome:</strong> " + nome + "</p>");

        if (emails != null) {
            for (String email : emails) {
                if (email != null && !email.trim().isEmpty()) {
                    out.println("<p><strong>E-mail:</strong> " + email + "</p>");
                }
            }
        }

        if (cursos != null) {
            for (String curso : cursos) {
                out.println("<p><strong>Curso escolhido:</strong> " + curso + "</p>");
            }
        } else {
            out.println("<p><strong>Nenhum curso selecionado.</strong></p>");
        }

        out.println("</body></html>");
    }
}
